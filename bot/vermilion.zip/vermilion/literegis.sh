#!/bin/bash
export HOME=/root
export TERM=xterm
NC='\e[0m'
enge="If disconnected, please enter the following command in the VPS: <code>screen -r -d setup</code> and press Enter."
indon="Jika Disconnect Saat Proses Penginstallan, Silahkan Masukkan Perintah Berikut Di VPS Untuk Menghubungkan Ulang: <code>screen -r -d setup</code> dan tekan Enter."
step1="apt update -y && apt upgrade -y --fix-missing && apt install -y xxd bzip2 wget curl sudo build-essential bsdmainutils screen dos2unix && update-grub && apt dist-upgrade -y && sleep 2 && reboot"
step2='screen -S setup-session bash -c "wget -q https://raw.githubusercontent.com/MuhammadIdsal/BangJali-Modder/main/install.sh && chmod +x install.sh && ./install.sh; read -p \"Tekan enter untuk keluar...\""'
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
ipsaya=$(curl -sS ipv4.icanhazip.com)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/MuhammadIdsal/BangJali-Modder/main/ip"
checking_sc() {
  useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
  if [[ $date_list < $useexp ]]; then
    echo -ne
  else
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          ANDA HARUS MENDAFTAR DAHULU UNTUK MENJADI SELLER         \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            ${RED}DAFTAR DULU DEK !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $ipsaya \033[0;33mHas been Banned${NC}"
    echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "      \033[0;36mTelegram${NC} t.me/LITE_VERMILION"
    echo -e "      ${GREEN}WhatsApp${NC} wa.me/6281934335091"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    exit
  fi
}
checking_sc
Repo1="https://raw.githubusercontent.com/MuhammadIdsal/BangJali-Modder/main/"
export MYIP=$( curl -sS ipv4.icanhazip.com/ )
SELLER=$(curl -sS ${Repo1}ip | grep $MYIP | awk '{print $2}')
Exp100=$(curl -sS ${Repo1}ip | grep $MYIP | awk '{print $3}')
data_ip="https://raw.githubusercontent.com/MuhammadIdsal/BangJali-Modder/main/ip"
d2=$(date -d "$date_list" +"+%s")
d1=$(date -d "$Exp" +"+%s")
dayleft=$(( ($d1 - $d2) / 86400 ))
####
TOKEN="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"
REPO="https://github.com/MuhammadIdsal/BangJali-Modder.git"
EMAIL="mf05386@gmail.com@gmail.com"
USER="MuhammadIdsal"
today=$(date -d "0 days" +"%Y-%m-%d")
#####

# Ambil parameter dari perintah addip
ip="$1"
name="$2"
exp="$3"

git clone ${REPO} /root/ipvps/
CLIENT_EXISTS=$(grep -w $ip /root/ipvps/ip | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
echo "IP Already Exist !"
rm -rf /root/ipvps
exit 0
fi

exp2=`date -d "${exp} days" +"%Y-%m-%d"`
echo "### ${name} ${exp2} ${ip}" >> /root/ipvps/ip

cd /root/ipvps
git config --global user.email "${EMAIL}"
git config --global user.name "${USER}"
rm -rf .git &> /dev/null
git init &> /dev/null
git add . &> /dev/null
git commit -m literegis &> /dev/null
git branch -M main &> /dev/null
git remote add origin https://github.com/Gall-x/link.git
git push -f https://${TOKEN}@github.com/Gall-x/link.git &> /dev/null
rm -rf /root/ipvps

echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "◇⟨IP SUCCESSFULLY REGISTER⟩◇"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "🏷️ Client Name : $name"
echo -e "✨IP Address  : $ip"
echo -e "📅 ️Expiry Date : $exp2"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "❇️ Langkah Pertama:"
echo -e "<code>$step1</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "❇️ Langkah Kedua:"
echo -e "<code>$step2</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "<code>$indon</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"