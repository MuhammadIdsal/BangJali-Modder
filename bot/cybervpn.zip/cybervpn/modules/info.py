from cybervpn import *
import time
import subprocess
from telethon import Button

# CEK VMESS
@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
    async def info_vps_(event):
        cmd = 'bot-vps-info'.strip()  # Perintah shell untuk mendapatkan info VPS
        
        await event.edit("**Please Wait...**")

        try:
            # Jalankan perintah shell dan tangkap outputnya
            x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            z = x.strip()  # Menghapus whitespace tambahan

            # Tampilkan hasil pada event
            await event.respond(f"```{z}```\n",
                                buttons=[[Button.inline("𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞", "menu")]])

            # Lakukan tindakan tambahan berdasarkan level pengguna
            chat = event.chat_id
            sender = await event.get_sender()
            user_id = sender.id
            level = get_level_from_db(user_id)  # Fungsi untuk mendapatkan level pengguna dari database

            print(f'Retrieved level from database: {level}')

            if level == 'admin':
                await create_ssh_(event)  # Panggil fungsi untuk admin
            else:
                await event.answer(f'Akses Ditolak..!!', alert=True)
  
        except Exception as e:
            print(f'Error: {e}')

    await info_vps_(event)
