from cybervpn import *
from telethon import events, Button
import requests


@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("𝚂𝚂𝙷", "ssh"),
                    Button.inline("𝚅𝚖𝚎𝚜𝚜", "vmess-member")],
                     [Button.inline("𝚅𝚕𝚎𝚜𝚜", "vless-member"),
                    Button.inline("𝚃𝚛𝚘𝚓𝚊𝚗", "trojan-member")],
                     [Button.inline("𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜", "shadowsocks-member"),
                    Button.inline("𝙽𝚘𝚘𝚋𝚣𝚟𝚙𝚗𝚜", "noobzvpn-member")],
                     [Button.inline("𝚃𝚘𝚙𝚄𝚙", f"topup")]
                ]
                
                
                ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
                vms = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
                vls = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
                trj = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
                shadowsocks = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
                namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
                ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
                z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
                
                vms_half = int(vms) // 2
                vls_half = int(vls) // 2
                trj_half = int(trj) // 2
                shadowsocks_half = int(shadowsocks) // 1
           
                member_msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨Hi, Selamat Datang Teman⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» ISP**: `{z["isp"]}`
**» Location**: `{z["country"]}`

**» Harga Produk: **
**» SSH    Rp.5.000 **
**» VMESS  Rp.5.000 **
**» VLESS  Rp.5.000 **
**» TROJAN Rp.5.000 **
**» SDWSOK Rp.5.000 **
**» NOOBZS Rp.5.000 **

**» 𝚂𝚜𝚑**: `{ssh}` __account__
**» 𝚅𝚖𝚎𝚜𝚜**: `{vms_half}` __account__
**» 𝚅𝚕𝚎𝚜𝚜**: `{vls_half}` __account__
**» 𝚃𝚛𝚘𝚓𝚊𝚗**: `{trj_half}` __account__
**» 𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜**: `{shadowsocks_half}` __account__
**◇━━━━━━━━━━━━━━━━━◇**
**» User ** `{user_id}`
**» Total User :** `{get_user_count()}`
**» Your Saldo: ** `Rp.{saldo_aji}`
**◇━━━━━━━━━━━━━━━━━◇**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("𝚂𝚂𝙷", "ssh"),
                    Button.inline("𝚅𝚖𝚎𝚜𝚜", "vmess")],
                     [Button.inline("𝚅𝚕𝚎𝚜𝚜", "vless"),
                    Button.inline("𝚃𝚛𝚘𝚓𝚊𝚗", "trojan")],
                     [Button.inline("𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜", "shadowsocks"),
                    Button.inline("𝙽𝚘𝚘𝚋𝚣𝚟𝚙𝚗𝚜", "noobzvpns")],
                     [Button.inline("𝙰𝚍𝚍 𝙼𝚎𝚖𝚋𝚎𝚛", "registrasi-member"),
                     Button.inline("𝙷𝚊𝚙𝚞𝚜 𝙼𝚎𝚖𝚋𝚎𝚛", "delete-member")],
                     [Button.inline("𝙳𝚊𝚏𝚝𝚊𝚛 𝙼𝚎𝚖𝚋𝚎𝚛", "show-user"),
                    Button.inline("𝙰𝚍𝚍 𝚂𝚊𝚕𝚍𝚘 𝚄𝚜𝚎𝚛", "addsaldo")],
                    [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝚅𝚙𝚜 𝙸𝚗𝚏𝚘", "info"),
                     Button.inline("𝙾𝚝𝚑𝚎𝚛 𝚂𝚎𝚝𝚝𝚒𝚗𝚐", "setting")],
                ]
                
                ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
                vms = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
                vls = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
                trj = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
                shadowsocks = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
                namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
                ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
                z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
                
                vms_half = int(vms) // 2
                vls_half = int(vls) // 2
                trj_half = int(trj) // 2
                shadowsocks_half = int(shadowsocks) // 1

                admin_msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨Hi, Selamat Datang Teman⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» ISP**: `{z["isp"]}`
**» Location**: `{z["country"]}`

**» Harga Produk: **
**» SSH    Rp.5.000 **
**» VMESS  Rp.5.000 **
**» VLESS  Rp.5.000 **
**» TROJAN Rp.5.000 **
**» SDWSOK Rp.5.000 **
**» NOOBZS Rp.5.000 **

**» 𝚂𝚜𝚑**: `{ssh}` __account__
**» 𝚅𝚖𝚎𝚜𝚜**: `{vms_half}` __account__
**» 𝚅𝚕𝚎𝚜𝚜**: `{vls_half}` __account__
**» 𝚃𝚛𝚘𝚓𝚊𝚗**: `{trj_half}` __account__
**» 𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜**: `{shadowsocks_half}` __account__
**◇━━━━━━━━━━━━━━━━━◇**
**» User ** `{user_id}`
**» Total User :** `{get_user_count()}`
**◇━━━━━━━━━━━━━━━━━◇**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'**Please register first**',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

