from cybervpn import *
import requests
import time
import subprocess
import random
import asyncio
import re
import datetime as DT

@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
    user_id = str(event.sender_id)

    async def create_shadowsocks_(event):
        try:
            async with bot.conversation(chat) as user_conv:
                await event.respond('**Username:**')
                user_msg = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = (await user_msg).raw_text

            async with bot.conversation(chat) as exp_conv:
                await event.respond('**Expired:**')
                exp_msg = exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp_msg).raw_text
   
            
            async with bot.conversation(chat) as ip_limit_conv:
                await event.respond('**Limit Quota:**')
                ip_limit_msg = ip_limit_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                ip_limit = (await ip_limit_msg).raw_text
                      
                      
            async with bot.conversation(chat) as Quota_conv:
                await event.respond('**Limit Ip:**')
                Quota_msg = Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                Quota = (await Quota_msg).raw_text
                 
            await event.edit("**Please Wait...**")
            cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip_limit}" | addss-bot'

            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")

        except subprocess.CalledProcessError as e:
            print(f"Error executing command: {e}")
            print(f"Exit code: {e.returncode}")
            print(f"Output: {e.output.decode('utf-8')}")
            await event.respond(f"Error executing command: {e}")
            return  # Stop execution to prevent further processing on error

        except Exception as ex:
            print(f"Unexpected error: {ex}")
            await event.respond("An unexpected error occurred.")
            return  # Stop execution to prevent further processing on error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        x = [x.group() for x in re.finditer("ss://(.*)", a)]
        uuid = re.search("ss://(.*?)@", x[0]).group(1)

        msg = f"""
        
**◇━━━━━━━━━━━━━━━━━◇**
  **◇⟨Shadowsocks Account⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{user}`
**» Domain :** `{DOMAIN}`
**» Port TLS    :** `443,8443`
**» Port NTLS   :** `80,2086,8080,8880`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/ss-ws`
**» ServiceName :** `ss-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{x[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP   :** 
```{x[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/ss-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**

        """

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await create_shadowsocks_(event)
        else:
            await event.answer(f'Akses Ditolak.!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')


@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
    user_id = str(event.sender_id)
    async def cek_shadowsocks_(event):
        cmd = 'cek-mss'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
        
        {z}

**Shows Users Shadowsocks in database**
        """, buttons=[[Button.inline("𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await cek_shadowsocks_(event)
        else:
            await event.answer('Akses Ditolak.!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')




@bot.on(events.CallbackQuery(data=b'cek-shadowsocks-online'))
async def cek_shadowsocks(event):
    user_id = str(event.sender_id)
    async def cek_shadowsocks_(event):
        cmd = 'cek-ss'.strip()
        result = subprocess.check_output(
            cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True, env={"TERM": "xterm"}
        )

        # Hapus karakter escape ANSI
        clean_result = re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', result).strip()

        await event.edit(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
**◇⟨Cek Shadowsocks User Login⟩◇**
**◇━━━━━━━━━━━━━━━━━━◇**
{clean_result}

**Shows Logged In Users Shadowsocks**
        """, buttons=[[Button.inline("𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await cek_shadowsocks_(event)
        else:
            await event.answer('Akses Ditolak.!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')


@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        # Periksa level pengguna
        level = get_level_from_db(sender.id)
        print(f'Retrieved level from database: {level}')

        if level != 'admin':
            await event.answer('Akses Ditolak.!!', alert=True)
            return

        # Minta username dari pengguna
        await event.respond('**Username:**')

        # Tunggu input dari pengguna
        user_response = await bot.wait_event(
            events.NewMessage(incoming=True, from_users=sender.id)
        )
        user_text = user_response.raw_text

        await event.edit("**Please Wait...**")
        cmd = f'printf "%s\n" "{user_text}" | bot-del-ss'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
            msg = f"**Successfully Deleted:** {user_text}"
        except subprocess.CalledProcessError:
            msg = "**Failed to Delete User. Please check the username.**"
        
        await event.respond(msg)

    except Exception as e:
        print(f'Error: {e}')
        await event.respond('Terjadi kesalahan. Silakan coba lagi.')


@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
    user_id = str(event.sender_id)
    
    async def trial_shadowsocks_(event):
        try:
            await event.edit("**Please Wait...**")
            cmd = f'printf "%s\n" "Trial$(</dev/urandom tr -dc X-Z0-9 | head -c4)" "1" "1" "1" | addss-bot'
            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")

        except subprocess.CalledProcessError as e:
            print(f"Error executing command: {e}")
            print(f"Exit code: {e.returncode}")
            print(f"Output: {e.output.decode('utf-8')}")
            await event.respond(f"Error executing command: {e}")
            return  # Stop execution to prevent further processing on error

        except Exception as ex:
            print(f"Unexpected error: {ex}")
            await event.respond("An unexpected error occurred.")
            return  # Stop execution to prevent further processing on error

        today = DT.date.today()
        later = today + DT.timedelta(days=1)
        
        # Parsing informasi dari output perintah untuk Shadowsocks
        x = [x.group() for x in re.finditer("ss://(.*)", a)]
        uuid = re.search("ss://(.*?)@", x[0]).group(1)
        remarks = re.search("#(.*)", x[0]).group(1)

        # Membuat pesan yang panjang
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨Trial Shadowsocks Account⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443,8443`
**» Port NTLS   :** `80,2086,8080,8880`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/ss-ws`
**» ServiceName :** `ss-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{x[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP   :** 
```{x[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/ss-{remarks}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** {today}
**◇━━━━━━━━━━━━━━━━━◇**
        """

        # Fungsi untuk membagi pesan panjang menjadi beberapa bagian
        def split_message(message, chunk_size=4096):
            return [message[i:i+chunk_size] for i in range(0, len(message), chunk_size)]

        # Memisahkan pesan panjang
        messages = split_message(msg)

        # Kirim setiap bagian pesan
        for message in messages:
            await bot.send_message(event.chat_id, message)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        # Memeriksa level akses dari database
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await trial_shadowsocks_(event)
        else:
            await event.answer(f'Akses Ditolak.!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"An error occurred: {e}")



@bot.on(events.CallbackQuery(data=b'renew-ss'))
async def ren_ss(event):
    async def ren_ss_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expired:**')
            exp = await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp.raw_text
        
        async with bot.conversation(chat) as Quota_conv:
            await event.respond('**Limit Quota:**')
            Quota = await Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = Quota.raw_text
        
        async with bot.conversation(chat) as ip_conv:
            await event.respond('**Limit Ip:**')
            ip = await ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = ip.raw_text
  
        await event.edit("**Please Wait...**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{Quota}" | bot-renew-ss'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Renewed User**")
        else:
            msg = f"""**Successfully Renewed  {user} {exp} Days**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await ren_ss_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
    user_id = str(event.sender_id)

    async def shadowsocks_(event):
        inline = [
            [Button.inline("𝚃𝚛𝚒𝚊𝚕", "trial-shadowsocks"),
             Button.inline("𝙲𝚛𝚎𝚊𝚝𝚎", "create-shadowsocks")],
            [Button.inline("𝙲𝚎𝚔", "cek-shadowsocks"),
            Button.inline("𝙲𝚎𝚔 𝚄𝚜𝚎𝚛 𝙾𝚗𝚕𝚒𝚗𝚎", "cek-shadowsocks-online")],
[Button.inline("𝚁𝚎𝚗𝚎𝚠 𝚄𝚜𝚎𝚛", "renew-ss"),
Button.inline("𝙷𝚊𝚙𝚞𝚜", "delete-shadowsocks")],
            [Button.inline("𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞", "menu")]]
        
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
         **◇⟨ Shadowsocks ⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
» Service: `Shadowsocks`
» Hostname/IP: `{DOMAIN}`
» ISP: `{z["isp"]}`
» Country: `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
"""

        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await shadowsocks_(event)
        else:
            await event.answer(f'Akses Ditolak.!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')


