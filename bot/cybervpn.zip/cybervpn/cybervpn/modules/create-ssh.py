from cybervpn import *
import asyncio
import aiohttp
import aiofiles
import datetime as DT
from telethon import events

async def get_ip_info():
    async with aiohttp.ClientSession() as session:
        async with session.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp") as response:
            return await response.json()

async def read_file_async(path):
    try:
        async with aiofiles.open(path, mode='r') as file:
            return (await file.read()).strip()
    except FileNotFoundError:
        return "Not found"

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_akun(event):
    async def create_akun_(event):
        async with bot.conversation(event.chat_id) as conv:
            await event.respond('**Username:**')
            user_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            user = user_msg.raw_text

            await event.respond('**Password:**')
            pw_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            pw = pw_msg.raw_text

            await event.respond('**Expired:**')
            exp_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            exp = exp_msg.raw_text

            await event.respond('**Limit IP:**')
            ip_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            ip = ip_msg.raw_text

            await event.respond('**Limit Quota:**')
            quota_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            Quota = quota_msg.raw_text

        await event.edit("**Please Wait...**`")

        cmd = f'printf "%s\n" "{user}" "{pw}" "{ip}" "{Quota}" "{exp}" | addssh-bot'
        process = await asyncio.create_subprocess_shell(
            cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        
        if process.returncode != 0:
            error_msg = stderr.decode().strip()
            await event.respond(f"Terjadi kesalahan: {error_msg}")
            return
        
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Menggunakan asyncio.gather untuk mempercepat pemrosesan
        NS, PUB, ip_info = await asyncio.gather(
            read_file_async('/etc/xray/dns'),
            read_file_async('/etc/slowdns/server.pub'),
            get_ip_info()
        )

        msg = f"""
◇━━━━━━━━━━━━━━━━━◇
      **◇⟨SSH Account ⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» ISP:** `{ip_info["isp"]}`
**» Location:** `{ip_info["country"]}`
**» Host:** `{DOMAIN}`
**» Host SlowDNS:** `{NS}`
**» Username:** `{user}`
**» Password:** `{pw}`
**» Limit Quota :** `{Quota} GB`
**» Limit Login :** `{ip} HP`
◇━━━━━━━━━━━━━━━━━◇
**» Pub Key:** `{PUB}`
**» Port OpenSsh :** 22
**» Port Dropbear :** 143,109
**» Port Ssh Ws :** 80,8080,2086,8880
**» Port Ssh Ws/Tls :**443,8443
**» Port Ssh Ssl/Tls :**443
**» Port Ssh UDP :** 1-65535 
**» BadVPN UDP :** 7100,7300,7300
◇━━━━━━━━━━━━━━━━━◇
**⟨FORMAT HTTP CUSTOM⟩**
`{DOMAIN}:1-65535@{user}:{pw}`
◇━━━━━━━━━━━━━━━━━◇
**⟨Save Account⟩**
https://{DOMAIN}:81/ssh-{user}.txt
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**» Expired Until:** {later}
◇━━━━━━━━━━━━━━━━━◇
"""
        await event.respond(msg)

    sender_id = str(event.sender_id)

    try:
        level = get_level_from_db(sender_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await create_akun_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')
